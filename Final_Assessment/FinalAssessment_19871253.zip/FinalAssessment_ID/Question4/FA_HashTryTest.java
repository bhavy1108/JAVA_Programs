/**
 * DSA Final Assessment Question 3 - MaxHeapTest.java
 *
 * Name : Seenarain Bhavyattaa
 * ID   : 19871253
 * Reference code from greeksforgreeks
 **/


import java.util.HashMap;

public class FA_HashTryTest
{
	public static void main(String args[])
	{
	
            // using built in datatype for hash tables
	    HashMap<Integer, String> hash = new HashMap<>();
	    hash.put(10, "Orange");
	    hash.put(20, "apple");
	    hash.put(60, "Pineapple");
	    hash.put(110, "Mango");
	    hash.put(219, "Watermelon");
	    
	    System.out.println("Size of inventory : " + hash.size());
	    System.out.println(hash);
	    
	 }
	 
}	 
	 
	 
	 
	 
