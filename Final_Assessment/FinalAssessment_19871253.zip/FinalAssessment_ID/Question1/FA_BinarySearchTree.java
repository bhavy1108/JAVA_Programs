/**
 * DSA Final Assessment Question 1 - FA_BinarySearchTree.java
 *
 * Name : Bhavyattaa Seenarain
 * ID   :19871253
 * Reference code from geeksforgeeks - the 2 last method in this class
 **/

public class FA_BinarySearchTree {   
	// Inner class FA_TreeNode
	private class FA_TreeNode {
		public int value;
		public FA_TreeNode left;
		public FA_TreeNode right;
		
		public FA_TreeNode(int inVal)
		{
			value = inVal;
			left = null;
			right = null;
		}
	}
	// Class FA_BinarySearchTree
	static FA_TreeNode root;
	
	public FA_BinarySearchTree()
	{
		root = null;
	}
	
	public void insert(int val)
	{
		if (isEmpty())
		{
			root = new FA_TreeNode(val);
		}
		else
		{
			root = insertRec(val, root);
		}
	}

	public Boolean isEmpty()
	{
		return root == null;
	}

	private FA_TreeNode insertRec(int inVal, FA_TreeNode cur)
	{
		if (cur == null)
		{
			cur = new FA_TreeNode(inVal);
		}
		else
		{
			if (inVal < cur.value)
			{
				cur.left = insertRec(inVal, cur.left);
			}
			else	
			{
				cur.right = insertRec(inVal, cur.right);
			}
		}
		return cur;
	}
	
	// method to diaplay the BST 
	void printEvenValues(FA_TreeNode root)
	{
		if ( root != null )
		{

			//traverse left subtree of the BST
			printEvenValues(root.left);
			System.out.println(root.value + "" );											
			//thus traverse right subtree of the BST
			printEvenValues(root.right);

		}		

	}
	
	
	
	//function to print odd nodes in the BST
	static void printEven(FA_TreeNode root)
	{
	
		if ( root != null)
		{
		
			printEven(root.left);
		}
		
		if (root.value % 2 != 0)
		 
		 System.out.println("" + root.value);
		 printEven(root.right); 	
	
       }
       
       // function to print odd levels in BST 
       static void printEvenLevels(FA_TreeNode root, boolean flag)
       {
       
       		if (root == null)
       		return;
       		
       		if (flag == true)
       		System.out.println("" + root.value);
       		
       		printEvenLevels(root.left, !flag);
       		printEvenLevels( root.right, !flag);
       		
      } 		

}






