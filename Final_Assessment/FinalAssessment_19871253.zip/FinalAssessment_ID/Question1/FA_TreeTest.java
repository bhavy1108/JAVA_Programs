/**
 * DSA Final Assessment Question 1 - FA_TreeTest.java
 *
 * Name :Bhavyattaa Seenarain
 * ID   : 19871253
 *
 **/
public class FA_TreeTest
{
	public static void main(String args[])
	{
	
		//FA_BinarySearchTree bst = new FA_BinarySearchTree();
		
		

		System.out.println(" Question 1: Testing Trees ");

			FA_BinarySearchTree bst = new FA_BinarySearchTree();

			bst.insert(63);
			bst.insert(21);
			bst.insert(83);
			bst.insert(7);
			bst.insert(39);
			bst.insert(71);
			
		
			System.out.println("\nPrint node with odd values  nodes in the BST .");
			 
			bst.printEvenValues(FA_BinarySearchTree.root); 
			
			//bst.BSToddNode(FA_BinarySearchTree.root);
			
			System.out.println( "\nPrint all values in odd levels : ");		
			bst.printEvenValues(FA_BinarySearchTree.root); 
			
		System.out.println(" \nTests Complete ");

	}
	
}
