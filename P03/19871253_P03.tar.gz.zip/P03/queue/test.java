import java.util.*;

public class test
{


    public static void main(String [] args)
    {
          Scanner sc = new Scanner(System.in);
          DsaShuffQ  s = DsaShuffQ();
   	  boolean check = true;

        int select;
     while(check == true)
     {
 
           select = 0;
           while((select < 1) || (select > 4))
           {

              System.out.println("Make a selection of the further choice.\n");
               System.out.println("1 : Adding item in the shuffling queue");              System.out.println("2 : Deleting item from the queue.");
               System.out.println("3 : Peek a value in the queue ");


          }




     }
    
    }
